OUTBREAK Android v3.0

Großes Gameplay-Upgrade:
- größere Open World mit Bäumen, Lampen und dichterer Umgebung
- erweiterte Gebäude mit Raumaufteilung und mehr Möbel-Loot
- Inventar mit Medizin, Essen, Wasser und Ressourcen
- Minimap und Kartenanzeige
- verbesserte Waffenrückmeldung, Mündungsblitz, Trefferstatistik und kritische Treffer
- Boss-Zombie, Runner, Tank und normale Zombies
- Fahrzeuge, Fuel, Shop, Quests, Skills, Basisbau
- Tag/Nacht, Regen, Touch-Steuerung
- lokales Speichern/Laden
- Android-WebView-Projekt

Hinweis:
Für eine vollständig offlinefähige Version muss die echte Three.js v0.161.0
Datei in app/src/main/assets/js/three.min.js liegen.
